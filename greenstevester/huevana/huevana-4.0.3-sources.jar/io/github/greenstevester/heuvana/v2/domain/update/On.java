package io.github.greenstevester.heuvana.v2.domain.update;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.github.greenstevester.heuvana.v2.domain.JsonStringUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class On {

  public static final On ON = new On(true);
  public static final On OFF = new On(false);

  @JsonProperty("on")
  private boolean on;

  public On(boolean on) {
    this.on = on;
  }

  public boolean isOn() {
    return on;
  }

  /**
   * Toggles the light on or off.
   *
   * @param on True for on, false for off.
   * @return Self, so that one can also use this method like a fluent builder.
   */
  public On setOn(boolean on) {
    this.on = on;
    return this;
  }

  @Override
  public String toString() {
    return JsonStringUtil.toJsonString(this);
  }
}
