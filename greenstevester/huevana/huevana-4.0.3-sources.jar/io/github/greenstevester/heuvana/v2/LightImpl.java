package io.github.greenstevester.heuvana.v2;

import io.github.greenstevester.heuvana.HueApiException;
import io.github.greenstevester.heuvana.v2.domain.Effects;
import io.github.greenstevester.heuvana.v2.domain.LightResource;
import io.github.greenstevester.heuvana.v2.domain.update.EffectType;
import io.github.greenstevester.heuvana.v2.domain.update.UpdateLight;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Supplier;

import static io.github.greenstevester.heuvana.v2.domain.update.On.OFF;
import static io.github.greenstevester.heuvana.v2.domain.update.On.ON;

public class LightImpl implements Light {
  private static final Logger logger = LoggerFactory.getLogger("io.github.greenstevester.yahueapi");

  private final UUID id;
  private final String idV1;
  private final UUID ownerId;
  private final String name;
  private final Supplier<LightResource> stateProvider;
  private final Function<UpdateLight, String> stateSetter;

  public LightImpl(final UUID id, final LightResource light, final Supplier<LightResource> stateProvider,
                   final Function<UpdateLight, String> stateSetter) {
    this.id = id;
    if (light == null) {
      throw new HueApiException("Light " + id + " cannot be found.");
    }
    this.name = light.getMetadata().getName();
    this.stateProvider = stateProvider;
    this.stateSetter = stateSetter;
    this.ownerId = light.getOwner().getResourceId();
    this.idV1 = light.getIdV1();
  }

  @Override
  public UUID getId() {
    return id;
  }

  public String getIdV1() {
    return idV1;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public void turnOn() {
    stateSetter.apply(new UpdateLight().setOn(ON));
  }

  @Override
  public void turnOff() {
    stateSetter.apply(new UpdateLight().setOn(OFF));
  }

  @Override
  public boolean isOn() {
    return getLightState().getOn().isOn();
  }

  private LightResource getLightState() {
    final LightResource state = stateProvider.get();
    logger.trace(state.toString());
    return state;
  }

  @Override
  public void setBrightness(final int brightness) {
    setState(new UpdateState().brightness(brightness).getUpdateLight());
  }

  @Override
  public void setState(final UpdateState state) {
    setState(state.getUpdateLight());
  }

  @Override
  public Collection<EffectType> getSupportedEffects() {
    return Optional.ofNullable(stateProvider.get().getEffects())
        .map(Effects::getEffectValues).orElse(Collections.emptyList());
  }

  private void setState(final UpdateLight state) {
    final String result = stateSetter.apply(state);
    logger.info("Update result: {}", result);
  }

  @Override
  public UUID getOwnerId() {
    return ownerId;
  }

  @Override
  public String toString() {
    return "Light{" +
        "id='" + id + '\'' +
        ", name='" + name + '\'' +
        '}';
  }
}
