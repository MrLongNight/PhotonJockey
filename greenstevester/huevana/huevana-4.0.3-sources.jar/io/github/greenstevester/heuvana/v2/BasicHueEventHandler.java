package io.github.greenstevester.heuvana.v2;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.launchdarkly.eventsource.MessageEvent;
import com.launchdarkly.eventsource.background.BackgroundEventHandler;
import io.github.greenstevester.heuvana.v2.domain.HueEvent;
import io.github.greenstevester.heuvana.v2.domain.event.ButtonEvent;
import io.github.greenstevester.heuvana.v2.domain.event.MotionEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Basic implementation of a Hue event handler that processes events from the Hue Bridge.
 */
public class BasicHueEventHandler implements BackgroundEventHandler {
  private static final Logger logger = LoggerFactory.getLogger(BasicHueEventHandler.class);
  /**
   * Type reference for deserializing lists of HueEvent objects.
   */
  public static final TypeReference<List<HueEvent>> EVENT_LIST_TYPE_REF = new TypeReference<List<HueEvent>>() {
  };

  private final ObjectMapper objectMapper;
  private final Hue hue;
  private final HueEventListener eventListener;

  /**
   * Creates a new BasicHueEventHandler.
   *
   * @param hue the Hue instance to use for object mapping
   * @param eventListener the listener to receive processed events
   */
  public BasicHueEventHandler(final Hue hue, final HueEventListener eventListener) {
    this.objectMapper = hue.objectMapper;
    this.hue = hue;
    this.eventListener = eventListener;
  }

  @Override
  public void onOpen() throws Exception {
    logger.trace("Connection opened.");
    eventListener.connectionOpened();
  }

  @Override
  public void onClosed() throws Exception {
    logger.trace("Connection closed.");
    eventListener.connectionClosed();
  }

  @Override
  public void onMessage(final String event, final MessageEvent messageEvent) throws Exception {
    logger.debug("Message: " + messageEvent.getData());
    final List<HueEvent> hueEvents = objectMapper.readValue(messageEvent.getData(), EVENT_LIST_TYPE_REF);
    eventListener.receive(hueEvents);
    parseAndAnnounceButtonEvents(hueEvents);
  }

  private void parseAndAnnounceButtonEvents(final List<HueEvent> hueEvents) {
    hueEvents.stream().flatMap(eventsItem ->
        eventsItem.getData().stream()
            .filter(data -> data.getButton().isPresent())
            .map(data -> {
              final Switch theSwitch = hue.getSwitches().get(data.getOwner().getResourceId());
              return new ButtonEvent(eventsItem.getCreationTime(),
                  theSwitch,
                  theSwitch.getButtons().get(data.getResourceId()),
                  ButtonEventType.parseFromButtonEventType(data.getButton().get().getLastEvent()),
                  eventsItem.getId());
            })
    ).forEach(eventListener::receiveButtonEvent);
    hueEvents.stream().flatMap(eventsItem ->
        eventsItem.getData().stream()
            .filter(data -> data.getMotion().isPresent())
            .map(motion -> {
              final Device device = hue.getMotionSensors().get(motion.getOwner().getResourceId());
              return new MotionEvent(eventsItem.getCreationTime(),
                  eventsItem.getId(),
                  device,
                  motion.getMotion().get().isMotion(),
                  motion.getMotion().get().isMotionValid()
              );
            })
    ).forEach(eventListener::receiveMotionEvent);
  }

  @Override
  public void onComment(final String comment) {
    logger.trace("Comment received: " + comment);
  }

  @Override
  public void onError(final Throwable t) {
    logger.info("onError: " + t);
  }
}
